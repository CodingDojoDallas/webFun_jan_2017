$(document).ready(function(){
	
	$("button").click(function(){
	  var location = $("input[name=weather]").val();
	  var data = "http://api.openweathermap.org/data/2.5/weather?q="+ location + "&&appid=9d328651486a5d01ef3900bc55fc1902";
		
		$.get('http://api.openweathermap.org/data/2.5/weather?q=' + location + '&&appid=9d328651486a5d01ef3900bc55fc1902',function (response) { 
			var fdegree = Math.floor((response.main.temp - 273)* (9/5) + 32);

			function type(){
			if(fdegree > 80){
				 return "Its warm outside";
			}
			else if (fdegree < 50){
				return "Bundle up";
			}
			else if((fdegree > 50)&&(fdegree < 80)){
				return "its nice out today";
			}

		}


			everything = '<h3>Temperature for ' + location +' is</h3>'
			everything += "<h5>" + fdegree + "</h5>";
			everything += "<h5>" + type() + "</h5>";
			$('#everything').html(everything)
			console.log(everything);

		
		},'json')
	})
})