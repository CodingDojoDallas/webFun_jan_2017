$(document).ready(function(){

 $('button').click(function(){

     	var first = $("input[name=first]").val();
     	var last = $("input[name=last]").val();
     	var about = $("textarea").val();
     	var data = '';


     data += "<div class='info'>"
     data += "<h1>" + first + "</h1>"
	 data += "<h2>" + last + "</h2>"
	 data += "<p>" + about + "<p>"
	 data += "</div>"
 	$('#dynamic').append(data);




 });

});
