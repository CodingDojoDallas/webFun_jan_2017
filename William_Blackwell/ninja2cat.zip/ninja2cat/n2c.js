$(document).ready(function(){
 



	$("#one").click(function(){
	$("#one").toggle("#one");
	});
	$(".stay").click(function(){
	$("#one").toggle();
	});

	$("#two").click(function(){
	$("#two").toggle("#one");
	});
	$(".stay1").click(function(){
	$("#two").toggle();
	});

	$("#three").click(function(){
	$("#three").toggle("#one");
	});
	$(".stay2").click(function(){
	$("#three").toggle();
	});

	$("#four").click(function(){
	$("#four").toggle("#one");
	});
	$(".stay3").click(function(){
	$("#four").toggle();
	});

	$("#five").click(function(){
	$("#five").toggle("#one");
	});
	$(".stay4").click(function(){
	$("#five").toggle();
	});
 





})