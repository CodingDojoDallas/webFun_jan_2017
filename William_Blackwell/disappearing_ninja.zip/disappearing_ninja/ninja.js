$(document).ready(function(){

	    $("#dojo").click(function(){
		$("body").css("color","red");
	});


})