$(document).ready(function(){
	    $("#dojo").click(function(){
		$("body").css("background-image","url(dojo.jpg)");
	});
	    $("#beach").click(function(){
		$("body").css("background-image","url(beach.jpg)");
	});
	    $("#links").click(function(){
	    $("#box").remove();
	    });
	    $("#links").click(function(){
	    $("h1").html("Select Players");
	    });


})