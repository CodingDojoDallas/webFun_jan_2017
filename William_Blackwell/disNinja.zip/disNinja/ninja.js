$(document).ready(function(){

	    $(".boxes").click(function(){
		$("#a").hide(".boxes");
	});

		$(".boxes1").click(function(){
		$("#b").hide(".boxes1");
	});

		$(".boxes2").click(function(){
		$("#c").hide("boxes2");
	});

		$(".boxes3").click(function(){
		$("#d").hide(".boxes3");
	});

		$(".boxes4").click(function(){
		$("#e").hide(".boxes4");
	});

		$(".boxes5").click(function(){
		$("#f").hide(".boxes5");
	});

		$(".boxes6").click(function(){
		$("#g").hide(".boxes6");
	});

		$(".boxes7").click(function(){
		$("#h").hide(".boxes7");
	});

		$("button").click(function(){
		$("#a").show();
	});

		$("button").click(function(){
		$("#b").show();
	});

		$("button").click(function(){
		$("#c").show();
	});

		$("button").click(function(){
		$("#d").show();
	});

		$("button").click(function(){
		$("#e").show();
	});

		$("button").click(function(){
		$("#f").show();
	});

		$("button").click(function(){
		$("#g").show();
	});

		$("button").click(function(){
		$("#h").show();
	});




})