$(document).ready(function(){

	    $("#red").click(function(){
		$("#redtext").css("color","red");
	});

	    $("#tog").click(function(){
		$("#append > h1").slideToggle("fast");

	});

	    $("#append").mouseenter(function(){
		$("#append").css("background-color","blue");
	});
		$("#append").mouseleave(function(){
		$("#append").css("background-color","red");
	});
		$("body > h2").click(function(){
		$("#wrapper").slideToggle();
	});
		$("#out").click(function(){
		$("#wrapper").fadeOut();
	});
		$("#in").click(function(){
		$("#wrapper").fadeIn();
	});
		$("#toggl > button").click(function(){
		$("#wrapper").append("<p>appended a new paragraph!</p>");
	});	
		$("#tog").click(function(){
		$("#tog").html("MADE YOU LOOK!");
	});


})